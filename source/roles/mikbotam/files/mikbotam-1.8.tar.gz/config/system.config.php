<?php

require_once 'system.medoo.php';

$mikbotamdata = new medoo([
      'database_type' => 'sqlite',
      'database_file' => '../config/mibotam.db',
]);

