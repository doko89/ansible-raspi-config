<?php

?>
    <div class="sl-pagebody">
    	<h1 class="tx-danger tx-center">Process Devlopemnt</h1>
    	                        <div class="row row-sm mg-t--1">
                            <div class="col-xl-6 mg-t-10">
      <div class="card bd-primary">
                    <div class="card-header bg-primary tx-white">
                        <i class="fa  fa-paper-plane"></i> Text Settings </div>
                    <div class="card-body pd-sm-15">
                        <form method="post" action="">
                           
                            <div class="row mg-t-8">
                                <label class="col-sm-4 form-control-label lead ">Text Welcome REG </label>
                                <div class="col-lg">
                                    <textarea id="textnya" rows="3" class="form-control" placeholder="*max 4200" style="margin-top: 0px; margin-bottom: 0px; height: 62px;" > </textarea>
                                </div>
                            </div>
                            <div class="row mg-t-8">
                                <label class="col-sm-4 form-control-label lead ">Text  Welcome UNREG</label>
                                <div class="col-lg">
                                    <textarea id="textnya" rows="3" class="form-control" placeholder="*max 4200" style="margin-top: 0px; margin-bottom: 0px; height: 62px;" > </textarea> 
                                </div>
                            </div>
                            <div class="row mg-t-8">
                                <label class="col-sm-4 form-control-label lead ">Text Cek saldo</label>
                                <div class="col-lg">
                                    <textarea id="textnya" rows="3" class="form-control" placeholder="*max 4200" style="margin-top: 0px; margin-bottom: 0px; height: 62px;" > </textarea> 
                                </div>
                            </div>
                            <div class="row mg-t-8">
                                <label class="col-sm-4 form-control-label lead ">Text Deposit </label>
                                <div class="col-lg">
                                    <textarea id="textnya" rows="3" class="form-control" placeholder="*max 4200" style="margin-top: 0px; margin-bottom: 0px; height: 62px;" > </textarea> 
                                </div>
                            </div>
                            <div class="row mg-t-8">
                                <label class="col-sm-4 form-control-label lead ">Text Voucher</label>
                                <div class="col-lg">
                                    <textarea id="textnya" rows="3" class="form-control" placeholder="*max 4200" style="margin-top: 0px; margin-bottom: 0px; height: 62px;" > </textarea> 
                                </div>
                            </div>
                            <div class="row mg-t-8">
                                <label class="col-sm-4 form-control-label lead ">Text on register</label>
                                <div class="col-lg">
                                    <textarea id="textnya" rows="3" class="form-control" placeholder="*max 4200" style="margin-top: 0px; margin-bottom: 0px; height: 62px;" > </textarea> 
                                </div>
                            </div>
                            <div class="row mg-t-8">
                                <label class="col-sm-4 form-control-label lead ">Text off register </label>
                                <div class="col-lg">
                                    <textarea id="textnya" rows="3" class="form-control" placeholder="*max 4200" style="margin-top: 0px; margin-bottom: 0px; height: 62px;" > </textarea> 
                                </div>
                            </div>
                        </form>
              
                    </div>
                  </div>
                </div>
                </div>
                </div>